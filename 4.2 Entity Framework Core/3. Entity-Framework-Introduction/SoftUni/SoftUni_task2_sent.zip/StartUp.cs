﻿using System;
//This project is made only for apploding the tasks in Judge - one by one. See 3 EntityFrameworkIntroduction Y Ex 1 till 15 for all tasks

//Should insall for every project:
//Microsoft.EntityFrameworkCore.SqlServer
//Microsoft.EntityFrameworkCore.Design

//For Judge in Tools\NuGet Package Manager\Package Manager Console run one by one this four lines: 3 for installing packages and the last one for connecting with the base:
//Install - Package Microsoft.EntityFrameworkCore.Tools –v 3.1.3
//Install - Package Microsoft.EntityFrameworkCore.SqlServer –v 3.1.3
//Install - Package Microsoft.EntityFrameworkCore.SqlServer.Design
//Scaffold-DbContext -Connection "Server=.;Database=SoftUni;Integrated Security=True;" -Provider Microsoft.EntityFrameworkCore.SqlServer -OutputDir Data/Models

namespace StartUp
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
