﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System.Text;
    using System.Linq;
    using System;
    using Microsoft.EntityFrameworkCore;
    using BookShop.Models.Enums;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);
            //2. Age Restriction
            string command = Console.ReadLine();
            Console.WriteLine(GetBooksByAgeRestriction(db, command));
        }
        //Mine - working
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            string commandNew = (command.ToUpper().Substring(0, 1) + command.ToLower().Substring(1, command.Length - 1));
            AgeRestriction commandCorrect = (AgeRestriction)Enum.Parse(typeof(AgeRestriction), commandNew);

            var books = context.Books
                .Where(x => x.AgeRestriction == commandCorrect)
                .Select(x => new { Title = x.Title})
                .OrderBy(x => x.Title)
                .ToList();

            StringBuilder sb = new StringBuilder();
            foreach (var book in books)
            {
                sb.AppendLine(book.Title);
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetBooksByAgeRestrictionEx(BookShopContext context, string command)
        {
            var commandCorrect = Enum.Parse<AgeRestriction>(command, true);//true ignores casing

            var books = context.Books
                .Where(x => x.AgeRestriction == commandCorrect)
                .Select(x => x.Title)//It shouldn't be .Select(x => new { Title = x.Title}) if we use string.Join()
                .OrderBy(x => x)
                .ToList();

            var result = string.Join(Environment.NewLine, books);

            return result;
        }
    }
}
