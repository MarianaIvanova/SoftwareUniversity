﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System.Text;
    using System.Linq;
    using System;
    using Microsoft.EntityFrameworkCore;
    using BookShop.Models.Enums;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);
            ////2. Age Restriction 
            //string command = Console.ReadLine();
            //Console.WriteLine(GetBooksByAgeRestriction(db, command));

            ////3. Golden Books
            //Console.WriteLine(GetGoldenBooks(db));

            //4. Books by Price
            Console.WriteLine(GetBooksByPrice(db));
        }
        //Mine - working
        public static string GetBooksByAgeRestrictionMine(BookShopContext context, string command)
        {
            string commandNew = (command.ToUpper().Substring(0, 1) + command.ToLower().Substring(1, command.Length - 1));
            AgeRestriction commandCorrect = (AgeRestriction)Enum.Parse(typeof(AgeRestriction), commandNew);

            var books = context.Books
                .Where(x => x.AgeRestriction == commandCorrect)
                .Select(x => new { Title = x.Title})
                .OrderBy(x => x.Title)
                .ToList();

            StringBuilder sb = new StringBuilder();
            foreach (var book in books)
            {
                sb.AppendLine(book.Title);
            }

            return sb.ToString().TrimEnd();
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            var commandCorrect = Enum.Parse<AgeRestriction>(command, true);//true ignores casing

            var books = context.Books
                .Where(x => x.AgeRestriction == commandCorrect)
                .Select(x => x.Title)//It shouldn't be .Select(x => new { Title = x.Title}) if we use string.Join()
                .OrderBy(x => x)
                .ToList();

            var result = string.Join(Environment.NewLine, books);

            return result;
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            //Mine:
            //var commandCorrect = Enum.Parse<EditionType>("Gold", false);//false doesn't ignores casing

            var books = context.Books
                //.Where(x => x.EditionType == commandCorrect && x.Copies < 5000)//Mine
                .Where(x => x.EditionType == EditionType.Gold && x.Copies < 5000)
                .Select(x => new
                {
                    BookId = x.BookId,
                    Title = x.Title
                })
                .OrderBy(x => x.BookId)
                .ToList();

            //StringBuilder sb = new StringBuilder();
            //foreach (var book in books)
            //{
            //    sb.AppendLine(book.Title);
            //}
            //return sb.ToString().TrimEnd();
            var result = string.Join(Environment.NewLine, books.Select(x => x.Title));

            return result;
        }
        public static string GetBooksByPrice(BookShopContext context)
        {
            var books = context.Books
                .Where(x => x.Price > 40)
                .Select(x => new
                {
                    Title = x.Title,
                    Price = x.Price,
                })
                .OrderByDescending(x => x.Price)
                .ToList();
            //Return in a single string all titles and prices of books with price higher than 40, each on a new row in the format given below. Order them by price descending.
            StringBuilder sb = new StringBuilder();
            foreach (var book in books)
            {
                sb.AppendLine($"{book.Title} - ${book.Price:F2}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
