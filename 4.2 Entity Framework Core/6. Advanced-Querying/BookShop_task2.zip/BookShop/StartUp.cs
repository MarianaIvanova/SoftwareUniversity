﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System.Text;
    using System.Linq;
    using System;
    using Microsoft.EntityFrameworkCore;
    using BookShop.Models.Enums;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);
            ////Task 2 
            //string command = Console.ReadLine();
            //Console.WriteLine(GetBooksByAgeRestriction(db, command));

            //Task 3 
            Console.WriteLine(GetGoldenBooks(db));
        }
        //Task 2 - Mine - working
        public static string GetBooksByAgeRestrictionMine(BookShopContext context, string command)
        {
            string commandNew = (command.ToUpper().Substring(0, 1) + command.ToLower().Substring(1, command.Length - 1));
            AgeRestriction commandCorrect = (AgeRestriction)Enum.Parse(typeof(AgeRestriction), commandNew);

            var books = context.Books
                .Where(x => x.AgeRestriction == commandCorrect)
                .Select(x => new { Title = x.Title})
                .OrderBy(x => x.Title)
                .ToList();

            StringBuilder sb = new StringBuilder();
            foreach (var book in books)
            {
                sb.AppendLine(book.Title);
            }

            return sb.ToString().TrimEnd();
        }
        //Task 2 
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            var commandCorrect = Enum.Parse<AgeRestriction>(command, true);//true ignores casing

            var books = context.Books
                .Where(x => x.AgeRestriction == commandCorrect)
                .Select(x => x.Title)//It shouldn't be .Select(x => new { Title = x.Title}) if we use string.Join()
                .OrderBy(x => x)
                .ToList();

            var result = string.Join(Environment.NewLine, books);

            return result;
        }
        public static string GetGoldenBooks(BookShopContext context)
        {
            var commandCorrect = Enum.Parse<EditionType>("Gold", false);//false doesn't ignores casing

            var books = context.Books
                .Where(x => x.EditionType == commandCorrect && x.Copies < 5000)
                .Select(x => new
                {
                    BookId = x.BookId,
                    Title = x.Title
                })
                .OrderBy(x => x.BookId)
                .ToList();

            StringBuilder sb = new StringBuilder();
            foreach (var book in books)
            {
                sb.AppendLine(book.Title);
            }

            return sb.ToString().TrimEnd();
        }
    }
}
