﻿using System;
using System.Linq;

namespace MusicHub
{
    using System;
    using System.Text;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            MusicHubDbContext context = 
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            //Test your solutions here
            int producerId = 9;// int.Parse(Console.ReadLine());
            Console.WriteLine(ExportAlbumsInfo(context, producerId));
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            //Mine
            //var producer = context.Producers
            //    .Include(x => x.Albums)
            //    .ThenInclude(x => x.Songs)
            //    .FirstOrDefault(x => x.Id == producerId)
            //    .Albums
            //    .Select(a => new
            //    {
            //        AlbumName = a.Name,
            //        ReleaseDate = a.ReleaseDate.ToString("MM/dd/yyyy"),
            //        ProducerName = a.Producer.Name,
            //        TotalPriceAlbum = a.Price,
            //        AlbumSongs = a.Songs
            //        .OrderByDescending(a => a.Name)
            //        .ThenBy(a => a.Writer.Name)
            //        .Select(b => new
            //        {
            //            SongName = b.Name,
            //            SongPrice = b.Price,
            //            SongWriterName = b.Writer.Name,
            //        })
            //    })
            //    .OrderByDescending(x => x.TotalPriceAlbum)
            //    .ToList();

            //StringBuilder sb = new StringBuilder();
            //foreach (var album in producer)
            //{
            //    sb.AppendLine($"-AlbumName: {album.AlbumName}");
            //    sb.AppendLine($"-ReleaseDate: {album.ReleaseDate}");
            //    sb.AppendLine($"-ProducerName: {album.ProducerName}");
            //    sb.AppendLine($"-Songs:");

            //    int count = 1;
            //    foreach (var song in album.AlbumSongs)
            //    {
            //        sb.AppendLine($"---#{count}");
            //        sb.AppendLine($"---SongName: {song.SongName}");
            //        sb.AppendLine($"---Price: {song.SongPrice:F2}");
            //        sb.AppendLine($"---Writer: {song.SongWriterName}");
            //        count++;
            //    }
            //    sb.AppendLine($"-AlbumPrice: {album.TotalPriceAlbum:F2}");
            //}

            //Teacher's:
            var producer = context.Producers
                .FirstOrDefault(x => x.Id == producerId)
                .Albums
                .Select(album => new
                {
                    AlbumName = album.Name,
                    ReleaseDate = album.ReleaseDate,
                    ProducerName = album.Producer.Name,
                    AlbumSongs = album.Songs
                    .Select(song => new
                    {
                        SongName = song.Name,
                        SongPrice = song.Price,
                        SongWriterName = song.Writer.Name,
                    })
                    .OrderByDescending(song => song.SongName)
                    .ThenBy(song => song.SongWriterName)
                    .ToList(),
                    AlbumPrice = album.Price,
                })
                .OrderByDescending(x => x.AlbumPrice)
                .ToList();

            StringBuilder sb = new StringBuilder();
            foreach (var album in producer)
            {
                sb.AppendLine($"-AlbumName: {album.AlbumName}")
                    .AppendLine($"-ReleaseDate: {album.ReleaseDate.ToString("MM/dd/yyyy")}")
                    .AppendLine($"-ProducerName: {album.ProducerName}")
                    .AppendLine($"-Songs:");

                int count = 1;
                foreach (var song in album.AlbumSongs)
                {
                    sb.AppendLine($"---#{count}")
                        .AppendLine($"---SongName: {song.SongName}")
                        .AppendLine($"---Price: {song.SongPrice:F2}")
                        .AppendLine($"---Writer: {song.SongWriterName}");
                    count++;
                }
                sb.AppendLine($"-AlbumPrice: {album.AlbumPrice:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        //{
        //    TimeSpan ts = TimeSpan.FromSeconds(duration);//convert int to TimeSpan

        //    var songs = context.Albums
        //        .Include(x => x.Songs)
        //        .ThenInclude(x => x.SongPerformers)
        //        .ThenInclude(x => x.Performer)
        //        .Where(x => x.Songs. > ts)
        //        .Select(x => new
        //        {
        //            SongName = //x.Name,
        //            PerformerFullName = x.SongPerformers.Select(x => new
        //            {
        //                PerformerFullName = $"{x.Performer.FirstName} {x.Performer.LastName}",
        //                WriterName = x.
        //                Album Producer and Duration(in format("c")).
        //            })


        //            ReleaseDate = a.ReleaseDate.ToString("MM/dd/yyyy"),
        //            ProducerName = a.Producer.Name,
        //            TotalPriceAlbum = a.Price,
        //            AlbumSongs = a.Songs
        //            .OrderByDescending(a => a.Name)
        //            .ThenBy(a => a.Writer.Name)
        //            .Select(b => new
        //            {
        //                SongName = b.Name,
        //                SongPrice = b.Price,
        //                SongWriterName = b.Writer.Name,
        //            })
        //        })
        //        .OrderByDescending(x => x.TotalPriceAlbum)
        //        .ToList();

        //    StringBuilder sb = new StringBuilder();
        //    foreach (var album in producer)
        //    {
        //        sb.AppendLine($"-AlbumName: {album.AlbumName}");
        //        sb.AppendLine($"-ReleaseDate: {album.ReleaseDate}");
        //        sb.AppendLine($"-ProducerName: {album.ProducerName}");
        //        sb.AppendLine($"-Songs:");

        //        int count = 1;
        //        foreach (var song in album.AlbumSongs)
        //        {
        //            sb.AppendLine($"---#{count}");
        //            sb.AppendLine($"---SongName: {song.SongName}");
        //            sb.AppendLine($"---Price: {song.SongPrice:F2}");
        //            sb.AppendLine($"---Writer: {song.SongWriterName}");
        //            count++;
        //        }
        //        sb.AppendLine($"-AlbumPrice: {album.TotalPriceAlbum:F2}");
        //    }

        //    return sb.ToString().TrimEnd();
        //}
    }
}
