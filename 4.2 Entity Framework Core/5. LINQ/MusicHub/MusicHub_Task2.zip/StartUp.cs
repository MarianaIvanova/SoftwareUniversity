﻿using System;
using System.Linq;

namespace MusicHub
{
    using System;
    using System.Text;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            MusicHubDbContext context = 
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            //Test your solutions here
            int producerId = 9;// int.Parse(Console.ReadLine());
            Console.WriteLine(ExportAlbumsInfo(context, producerId));
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            var producer = context.Producers
                .Include(x => x.Albums)
                .ThenInclude(x => x.Songs)
                .FirstOrDefault(x => x.Id == producerId)
                .Albums
                .Select(a => new
                {
                    AlbumName = a.Name,
                    ReleaseDate = a.ReleaseDate.ToString("MM/dd/yyyy"),
                    ProducerName = a.Producer.Name,
                    TotalPriceAlbum = a.Price,
                    AlbumSongs = a.Songs
                    .OrderByDescending(a => a.Name)
                    .ThenBy(a => a.Writer.Name)
                    .Select(b => new
                    {
                        SongName = b.Name,
                        SongPrice = b.Price,
                        SongWriterName = b.Writer.Name,
                    })
                })
                .OrderByDescending(x => x.TotalPriceAlbum)
                .ToList();

            StringBuilder sb = new StringBuilder();
            foreach (var album in producer)
            {
                sb.AppendLine($"-AlbumName: {album.AlbumName}");
                sb.AppendLine($"-ReleaseDate: {album.ReleaseDate}");
                sb.AppendLine($"-ProducerName: {album.ProducerName}");
                sb.AppendLine($"-Songs:");

                int count = 1;
                foreach (var song in album.AlbumSongs)
                {
                    sb.AppendLine($"---#{count}");
                    sb.AppendLine($"---SongName: {song.SongName}");
                    sb.AppendLine($"---Price: {song.SongPrice:F2}");
                    sb.AppendLine($"---Writer: {song.SongWriterName}");
                    count++;
                }
                sb.AppendLine($"-AlbumPrice: {album.TotalPriceAlbum:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            throw new NotImplementedException();
        }
    }
}
