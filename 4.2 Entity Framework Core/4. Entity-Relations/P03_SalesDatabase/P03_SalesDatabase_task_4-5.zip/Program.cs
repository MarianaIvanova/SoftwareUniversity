﻿using P03_SalesDatabase.Data;
using System;
//Part of 4. Entity-Relations

namespace P03_SalesDatabase
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //var context = new SalesContext();
            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();
        }
    }
}
