﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Y_Ex_7_Raw_Data
{
    public class Engine
    {
        public Engine(int speed, int power)
        {
            Speed = speed;
            Power = power;
        }
        public int Speed { get; set; }
        public int Power { get; set; }
    }
}
