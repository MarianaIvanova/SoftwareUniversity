﻿namespace Problem02.Stack
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class Stack<T> : IAbstractStack<T>
    {
        private Node<T> _top;

        public int Count { get; private set; }

        public bool Contains(T item)
        {
            bool isThereElement = false;

            var current = _top;

            while(current != null)
            {
                if(current.Value.Equals(item))
                {
                    isThereElement = true;
                }

                current = current.Next;
            }

            return isThereElement;
        }
        public T Peek()
        {
            this.InsureNotEmpty();

            return _top.Value;
        }

        public T Pop()
        {
            this.InsureNotEmpty();
            var _topOld = _top;

            _top = _top.Next;
            Count--;

            return _topOld.Value;
        }

        public void Push(T item)
        {
            Node<T> newNode = new Node<T>(item);
            newNode.Next = _top;
            this._top = newNode;
            Count++;
        }

        public IEnumerator<T> GetEnumerator()
        {
            Node<T> current = _top;

            while (current != null)
            {
                yield return current.Value;
                current = current.Next;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
            => GetEnumerator();

        private void InsureNotEmpty()
        {
            if(Count == 0)
            {
                throw new InvalidOperationException();
            }
        }
    }
}