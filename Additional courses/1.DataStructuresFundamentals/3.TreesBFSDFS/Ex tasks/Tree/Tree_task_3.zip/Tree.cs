﻿namespace Tree
{
    using System;
    using System.Text;
    using System.Collections.Generic;

    public class Tree<T> : IAbstractTree<T>
    {
        private readonly List<Tree<T>> _children;

        public Tree(T key, params Tree<T>[] children)
        {
            this.Key = key;
            _children = new List<Tree<T>>();

            foreach (var child in children)
            {
                this.AddChild(child);//this._children.Add(child);
                child.AddParent(this);//child.Parent = this;
            }
        }

        public T Key { get; private set; }

        public Tree<T> Parent { get; private set; }


        public IReadOnlyCollection<Tree<T>> Children
            => this._children.AsReadOnly();

        public void AddChild(Tree<T> child)
        {
            this._children.Add(child);
        }

        public void AddParent(Tree<T> parent)
        {
            this.Parent = parent;
        }

        //Task 2
        public string GetAsString()//DFS - стандартен с рекурсия
        {
            //Mine
            //StringBuilder sb = new StringBuilder();

            //var list = DFS(this, 0);
            ////var list = DFSstack(this, 0);
            //for (int i = 0; i < list.Count; i++)
            //{
            //    sb.AppendLine(list[i].ToString());
            //}

            //return sb.ToString().TrimEnd();

            return this.GetAsString(0).TrimEnd();
        }

        public Tree<T> GetDeepestLeftomostNode()
        {
            throw new NotImplementedException();
        }

        public List<T> GetLeafKeys()
        {
            List<T> list = new List<T>();
            Queue<Tree<T>> queue = new Queue<Tree<T>>();

            queue.Enqueue(this);

            while(queue.Count > 0)
            {
                Tree<T> subtree = queue.Dequeue();
                if(subtree.Children.Count == 0)//Only leafs i.e. without children
                {
                    list.Add(subtree.Key);
                }

                foreach (var child in subtree.Children)
                {
                    queue.Enqueue(child);
                }
            }

            return list;
        }

        public List<T> GetMiddleKeys()
        {
            throw new NotImplementedException();
        }

        public List<T> GetLongestPath()
        {
            throw new NotImplementedException();
        }

        public List<List<T>> PathsWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }

        public List<Tree<T>> SubTreesWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }

        //Task 2 - Mine - like the teachings from lab
        private List<string> DFS(Tree<T> subtree, int level)
        {
            List<string> list = new List<string>();

            string vs = new string(' ', level);
            list.Add($"{vs}{subtree.Key}");

            foreach (var child in subtree.Children)
            {
                list.AddRange(DFS(child, level + 2));
            }

            return list;
        }

        //Task 2 - teacher from the exercises
        private string GetAsString(int identification = 0)//Override на метода
        {
            var result = new string(' ', identification) + this.Key + "\r\n";//при първия път влиза в root

            foreach (var child in this.Children)
            {
                result += child.GetAsString(identification + 2);//тук при децата
            }

            return result;
        }
        //Task 2 - NOT OK
        //private List<string> DFSstack(Tree<T> subtree, int level)
        //{
        //    List<string> list = new List<string>();
        //    Stack<Tree<T>> stack = new Stack<Tree<T>>();
        //    Stack<int> stackLevel = new Stack<int>();
        //    stack.Push(subtree);
        //    stackLevel.Push(level);

        //    while (stack.Count > 0)
        //    {
        //        Tree<T> currentSubtree = stack.Pop();

        //        var distance = stackLevel.Pop();
        //        string vs = new string(' ', distance * 2);
        //        list.Add($"{vs}{currentSubtree.Key}");

        //        if (currentSubtree.Children.Count > 0)
        //        {
        //            level++;
        //        }
        //        else
        //        {
        //            if (currentSubtree.Parent != null)
        //            {
        //                if (distance != stackLevel.Peek())
        //                {
        //                    level--;
        //                }
        //            }
        //        }
        //        foreach (var child in currentSubtree.Children)
        //        {
        //            stack.Push(child);
        //            stackLevel.Push(level);
        //        }
        //    }

        //    return list;
        //}

        //Task 3
    }
}
