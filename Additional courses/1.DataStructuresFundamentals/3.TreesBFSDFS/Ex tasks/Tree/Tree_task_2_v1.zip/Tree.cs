﻿namespace Tree
{
    using System;
    using System.Text;
    using System.Collections.Generic;

    public class Tree<T> : IAbstractTree<T>
    {
        private readonly List<Tree<T>> _children;

        public Tree(T key, params Tree<T>[] children)
        {
            this.Key = key;
            _children = new List<Tree<T>>();

            foreach (var child in children)
            {
                this.AddChild(child);//this._children.Add(child);
                child.AddParent(this);//child.Parent = this;
            }
        }

        public T Key { get; private set; }

        public Tree<T> Parent { get; private set; }


        public IReadOnlyCollection<Tree<T>> Children
            => this._children.AsReadOnly();

        public void AddChild(Tree<T> child)
        {
            this._children.Add(child);
        }

        public void AddParent(Tree<T> parent)
        {
            this.Parent = parent;
        }

        public string GetAsString()//DFS - стандартен с рекурсия
        {
            StringBuilder sb = new StringBuilder();

            var list = DFS(this, 0);
            for (int i = 0; i < list.Count; i++)
            {
                sb.AppendLine(list[i].ToString());
            }

            return sb.ToString().TrimEnd();
        }

        public Tree<T> GetDeepestLeftomostNode()
        {
            throw new NotImplementedException();
        }

        public List<T> GetLeafKeys()
        {
            throw new NotImplementedException();
        }

        public List<T> GetMiddleKeys()
        {
            throw new NotImplementedException();
        }

        public List<T> GetLongestPath()
        {
            throw new NotImplementedException();
        }

        public List<List<T>> PathsWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }

        public List<Tree<T>> SubTreesWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }

        private List<string> DFS(Tree<T> subtree, int level)
        {
            List<string> list = new List<string>();

            string vs = new string(' ', level);
            list.Add($"{vs}{subtree.Key}");

            foreach (var child in subtree.Children)
            {
                list.AddRange(DFS(child, level + 2));
            }

            return list;
        }

        //private List<string> BFS(Tree<T> subtree, int level)
        //{
        //    List<string> list = new List<string>();
        //    Queue<Tree<T>> queue = new Queue<Tree<T>>();
        //    Queue<int> queueLevel = new Queue<int>();
        //    queue.Enqueue(subtree);
        //    queueLevel.Enqueue(level);

        //    while (queue.Count > 0)
        //    {
        //        Tree<T> currentSubtree = queue.Dequeue();

        //        var distance = queueLevel.Dequeue();
        //        string vs = new string(' ', distance * 2);
        //        list.Add($"{vs}{currentSubtree.Key}");

        //        if(currentSubtree.Children.Count > 0)
        //        {
        //            level++;
        //        }
        //        else
        //        {
        //            if(currentSubtree.Parent != null)
        //            {
        //                if(distance != queueLevel.Peek())
        //                {
        //                    level--;
        //                }
        //            }
        //        }
        //        foreach (var child in currentSubtree.Children)
        //        {
        //            queue.Enqueue(child);
        //            queueLevel.Enqueue(level);
        //        }
        //    }

        //    return list;
        //}
    }
}
