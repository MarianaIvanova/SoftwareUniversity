﻿namespace Tree
{
    using System;
    using System.Linq;
    using System.Collections.Generic;

    public class Tree<T> : IAbstractTree<T>
    {
        private readonly List<Tree<T>> _children;

        public Tree(T value)
        {
            Value = value;
            Parent = null;
            _children = new List<Tree<T>>();
        }

        public Tree(T value, params Tree<T>[] children)
            : this(value)
        {
            _children = children.ToList();
        }

        ////Implamantation from lab
        //public Tree(T value, params Tree<T>[] children)
        //    : this(value)
        //{
        //    foreach (var child in children)
        //    {
        //        child.Parent = this;
        //        this._children.Add(child);
        //    }
        //}

        public T Value { get; private set; }
        public Tree<T> Parent { get; private set; }
        public IReadOnlyCollection<Tree<T>> Children => this._children.AsReadOnly();

        public ICollection<T> OrderBfs()
        {
            Queue<Tree<T>> queue = new Queue<Tree<T>>();
            List<T> list = new List<T>();
            queue.Enqueue(this);//!!!

            while(queue.Count > 0)
            {
                Tree<T> subtree = queue.Dequeue();
                list.Add(subtree.Value);

                foreach (var child in subtree._children)
                {
                    queue.Enqueue(child);
                }
            }

            return list;
        }

        ////Implamantation from lab
        //public ICollection<T> OrderDfs()
        //{
        //    List<T> list = new List<T>();

        //    Dfs(this, list);

        //    return list;
        //}

        //private void Dfs(Tree<T> subtree, List<T> list)
        //{
        //    foreach (var child in subtree._children)
        //    {
        //        Dfs(child, list);
        //    }

        //    list.Add(subtree.Value);
        //}

        //Solution 1 - using recursion
        //public ICollection<T> OrderDfs()
        //{
        //    return Dfs(this);
        //}

        //private List<T> Dfs(Tree<T> subtree)
        //{
        //    List<T> list = new List<T>();

        //    foreach (var child in subtree.Children)
        //    {
        //        list.AddRange(Dfs(child));
        //    }

        //    list.Add(subtree.Value);

        //    return list;
        //}

        //Solution 2 - using stack - Mine - not OK
        public ICollection<T> OrderDfs()
        {
            Stack<Tree<T>> stack = new Stack<Tree<T>>();
            List<T> list = new List<T>();
            stack.Push(this);//!!!

            while (stack.Count > 0)
            {
                Tree<T> subtree = stack.Pop();
                list.Add(subtree.Value);

                foreach (var child in subtree._children)
                {
                    stack.Push(child);
                }
            }

            List<T> reversedList = new List<T>();

            for (int i = 0; i < list.Count; i++)
            {
                reversedList.Add(list[list.Count - 1 - i]);
            }

            return reversedList;
        }

        public void AddChild(T parentKey, Tree<T> child)
        {
            var serchedTree = SearchTree(this, parentKey);

            if(serchedTree == null)
            {
                throw new ArgumentNullException();
            }

            serchedTree._children.Add(child);
            
        }

        private Tree<T> SearchTree(Tree<T> root, T searchedKey)
        {
            Queue<Tree<T>> queue = new Queue<Tree<T>>();
            queue.Enqueue(root);

            while(queue.Count > 0)
            {
                var node = queue.Dequeue();

                if(node.Value.Equals(searchedKey))
                {
                    return node;
                }

                foreach (var child in node._children)
                {
                    queue.Enqueue(child);
                }
            }

            return null;
        }

        public void RemoveNode(T nodeKey)
        {
            throw new NotImplementedException();
        }

        public void Swap(T firstKey, T secondKey)
        {
            throw new NotImplementedException();
        }
    }
}
