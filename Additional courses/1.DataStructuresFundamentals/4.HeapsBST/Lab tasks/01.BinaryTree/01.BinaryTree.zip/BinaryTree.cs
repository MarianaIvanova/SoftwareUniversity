﻿namespace _01.BinaryTree
{
    using System;
    using System.Collections.Generic;

    public class BinaryTree<T> : IAbstractBinaryTree<T>
    {
        public BinaryTree(T value
            , IAbstractBinaryTree<T> leftChild
            , IAbstractBinaryTree<T> rightChild)
        {
            this.Value = value;
            this.LeftChild = leftChild;
            this.RightChild = rightChild;
        }

        public T Value { get; private set; }

        public IAbstractBinaryTree<T> LeftChild { get; private set; }

        public IAbstractBinaryTree<T> RightChild { get; private set; }

        public string AsIndentedPreOrder(int indent)
        {
            return DFSPreOrder(this, 0);
        }

        private string DFSPreOrder(IAbstractBinaryTree<T> node, int indent)
        {
            string result = $"{new string(' ', indent)}{node.Value}\r\n";
            if (node.LeftChild != null)
            {
                result += DFSPreOrder(node.LeftChild, indent + 2);
            }

            if (node.RightChild != null)
            {
                result += DFSPreOrder(node.RightChild, indent + 2);
            }

            return result;
        }
        public List<IAbstractBinaryTree<T>> InOrder()
        {
            return DFSInOrder(this);
        }

        private List<IAbstractBinaryTree<T>> DFSInOrder(IAbstractBinaryTree<T> node)
        {
            List<IAbstractBinaryTree<T>> list = new List<IAbstractBinaryTree<T>>();

            if (node.LeftChild != null)
            {
                list.AddRange(DFSInOrder(node.LeftChild));
            }

            list.Add(node);

            if (node.RightChild != null)
            {
                list.AddRange(DFSInOrder(node.RightChild));
            }

            return list;
        }
        public List<IAbstractBinaryTree<T>> PostOrder()
        {
            return DFSPostOrder(this);
        }
        private List<IAbstractBinaryTree<T>> DFSPostOrder(IAbstractBinaryTree<T> node)
        {
            List<IAbstractBinaryTree<T>> list = new List<IAbstractBinaryTree<T>>();

            if (node.LeftChild != null)
            {
                list.AddRange(DFSPostOrder(node.LeftChild));
            }

            if (node.RightChild != null)
            {
                list.AddRange(DFSPostOrder(node.RightChild));
            }

            list.Add(node);

            return list;
        }
        public List<IAbstractBinaryTree<T>> PreOrder()
        {
            return DFSPreOrder(this);
        }

        private List<IAbstractBinaryTree<T>> DFSPreOrder(IAbstractBinaryTree<T> node)
        {
            List<IAbstractBinaryTree<T>> list = new List<IAbstractBinaryTree<T>>();
            list.Add(node);

            if (node.LeftChild != null)
            {
                list.AddRange(DFSPreOrder(node.LeftChild));
            }

            if (node.RightChild != null)
            {
                list.AddRange(DFSPreOrder(node.RightChild));
            }

            return list;
        }
        public void ForEachInOrder(Action<T> action)
        {
            if(this.LeftChild != null)
            {
                this.LeftChild.ForEachInOrder(action);
            }

            action.Invoke(this.Value);

            if(this.RightChild != null)
            {
                this.RightChild.ForEachInOrder(action);
            }
        }
    }
}
